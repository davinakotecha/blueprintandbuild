# Synthetic orders for demos

> SAMPLE. This folder shows what a file-type MVP looks like. It is not a real MVP.

## Problem

Demos and training sessions need realistic order data, but client data is never allowed. People end up making up rows by hand, and every demo looks different.

## Who it's for

Anyone who runs a demo, a workshop or a training session and needs data that looks real.

## Use it in 5 minutes

1. Unzip this folder.
2. Open `sample-orders.csv` in Excel, or load it into Power BI with Get data > Text/CSV.
3. The columns are `order_id`, `order_date`, `region`, `product` and `amount`. Every row is invented.

## Limitations

- Retired: it was replaced by a better generator and is no longer updated.
- It is a tiny sample, not a full dataset.
- Shipped as is, with no support commitment.

## Owners

Sample data: Builder one and Builder two.

## Feedback

Post in #blueprint-and-build on Slack.
