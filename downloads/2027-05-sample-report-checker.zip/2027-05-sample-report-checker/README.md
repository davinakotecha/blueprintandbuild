# Report standards checker

> SAMPLE. This folder shows an MVP that is still being built. It is not a real MVP.

## Problem

Reports go out with different layouts, names and colours, and accessibility is checked by eye if at all. Reviewers repeat the same comments on every report.

## Who it's for

Report authors and reviewers in the practice.

## Use it in 5 minutes

Not ready yet. When it ships, this section will say how to open the checker and run it on a report. The catalog card shows "Link coming soon" until then.

## Limitations

- Still in the Build month: the scope may change.
- It will only check the rules written in the practice standards.
- Shipped as is, with no support commitment.

## Owners

Sample data: Builder one and Builder two.

## Feedback

Post in #blueprint-and-build on Slack.
