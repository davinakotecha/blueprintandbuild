# Lessons learned report

Turn your project documents into a one-page report of what to carry forward, with the exact words that prove each lesson.

It has two parts:

- **A Claude skill** (`lessons-learned/`) that reads close-out reports, retrospectives, status reports and RAID logs and writes a file called `lessons.json`.
- **An offline report** (`lessons-report.html`) that opens `lessons.json` and shows the top lessons, the themes, the root causes and the evidence behind each one. It is a single file. Double-click it and it works, with no internet.

## Problem

Lessons from finished projects sit in close-out documents that nobody opens again. When someone does write them up, you cannot tell which lessons come from the documents and which are somebody's opinion, so they are easy to ignore.

## Who it's for

Project leads, delivery managers and anyone starting a project who wants to learn from the last one. Also anyone who has to write a close-out report and would like a head start.

## Use it in 3 steps

1. **Give Claude your documents and the skill.** Add the `lessons-learned` folder to Claude as a skill (the Skills page on the site shows how). Then attach or paste your close-out report, retrospectives, status reports or RAID log and ask: "Use the lessons-learned skill to write lessons.json from these documents."
2. **Save the result as `lessons.json`.** Claude writes the file, or gives you one block of JSON to save under that name.
3. **Open `lessons-report.html` and drop `lessons.json` onto it.** Or click the button to load the built-in example first.

## Use it in 10 minutes (demo script)

This uses the example project in the `example/` folder, a made-up knowledge-base replacement called Project Compass at a fictional insurer. Everything in it is invented.

| Minute | What to do | What to say |
|---|---|---|
| 0 to 1 | Open `lessons-report.html` by double-clicking it. Click the button to load the example. | "No server, no sign-in. It is one file and it runs offline." |
| 1 to 3 | Read the top lessons to carry forward. Point at the confidence badges. | "These are the five lessons to take to the next project. The badge shows how well the documents back each one up." |
| 3 to 4 | Look at the theme breakdown and the root-cause breakdown. | "Among the things that went wrong, untested assumptions are the biggest single cause, ahead of late decisions, untracked dependencies and missing process. The technology is not the main problem. The hatched part of each bar is where Claude inferred the cause." |
| 4 to 5 | Use the phase filter and choose **Test**. | "Everything on screen is now what to act on during testing: the load test, booking agent time for acceptance testing, and single sign-on timeouts." |
| 5 to 7 | Open the evidence for one lesson. Compare the quote with `example/01-closeout-report.md`. Then, under **Where these lessons came from**, choose **Check the quotes against your documents** and select the three files in `example/`. | "The quote is word for word from the document and the section is named. If Claude had made it up, you could not find it. And the report can check every quote for you, on your own computer." |
| 7 to 8 | Export to Markdown. Open the file. | "That drops straight into a close-out report or a wiki page." |
| 8 to 9 | Print the report and choose Save as PDF. | "The print layout keeps the lessons and drops the controls." |
| 9 to 10 | Show the skill running. Give Claude the three files in `example/` and ask for a `lessons.json`. Drop the result onto the report. | "Same documents, new run. Compare it with the example and see what it kept, what it dropped and what it marked low confidence." |

## What the skill writes

Each lesson in `lessons.json` has:

- a **title**, a **theme** (for example Data, or Governance & decisions) and the **phase** it applies to;
- **what happened**, in the documents' own terms;
- one to four **evidence quotes**, copied word for word, each with the document and section;
- the **root cause**, marked as stated by the documents or inferred by Claude;
- the **impact**, the **recommendation** for the next project, and a **confidence** rating with the reason.

Lessons are either **improve** (do differently) or **sustain** (it went well, keep doing it). The full list of fields and allowed values is in `lessons-learned/SKILL.md`.

## Data rules

- Use **internal, public or synthetic** documents only.
- **No client names, no client data and no personal data** in the documents you give Claude, and none in the report you share.
- The viewer runs entirely in your browser. It makes no network calls, and nothing leaves your computer when you open a file.
- Before you share an exported report, read it once. Claude is told to leave names out, but you are the final check.

## Limitations

- **Claude can misread.** It may pick the wrong cause or call something a lesson that is really a one-off. Read the evidence quotes and check them against the source before you rely on a lesson.
- **Confidence badges are a guide, not a guarantee.** *High* means the documents state both the event and the cause. *Medium* means the event is clear but the cause is Claude's reading. *Low* means one weak mention.
- It can only learn from what the documents say. If a theme is missing, the documents probably did not cover it, and the skill's summary lists these gaps.
- A very long set of documents may need to be split into several runs. Keep each quote to the document it came from.
- Shipped as is, with no support commitment.

## What is in this folder

- `lessons-report.html` the offline report
- `lessons-learned/SKILL.md` the Claude skill, plus `example-closeout.md` as a sample input
- `example/` three made-up project documents and the `lessons.json` the skill would write from them (24 lessons)
- `mvp.json` the card details for the site

## Owners

Davina Kotecha and Owen Rogan (Blueprint & Build team).

## Feedback

Post in #blueprint-and-build on Slack.
