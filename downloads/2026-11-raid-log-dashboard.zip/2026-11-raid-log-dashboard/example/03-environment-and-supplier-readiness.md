# Project Kestrel: Environment and Supplier Readiness Note

21 October 2026. Written by the Test Manager and the Integration Lead for the Programme Manager.

> Synthetic example. Alderbrook Water and Project Kestrel are fictional.

## 1 Summary

Three things need attention before SIT starts on 9 November 2026: the BillCore sandbox is unreliable, Rehearsal 1 showed more duplicate accounts than the business will accept, and the performance environment is too small to prove peak load. Supplier commitments are broadly on track but mostly verbal.

## 2 Environments

### 2.1 BillCore sandbox

Over the last 14 days the BillCore sandbox was available 62% of the time against a target of 95%. This has been a problem since 5 October 2026. The vendor has scheduled a stability patch for 30 October 2026. Until it lands, integration developers lose about a day a week.

### 2.2 Performance environment

The performance environment is 25% of production capacity. The hosting supplier can raise it to 50% for £14,000 a month, but this is not approved. At 25% the results will not show whether the portal can take the expected peak, and the 80 calls per second peak against BillCore can only be simulated, not proven.

### 2.3 Payments gateway sandbox

The sandbox certificate expired on 12 October 2026 and blocked payment tests. The provider renewed it on 14 October 2026 and payment tests have resumed. The provider has also announced a change freeze from 16 November 2026 to 8 January 2027 for its peak trading period. No credential or configuration changes will be accepted during the freeze.

## 3 Data readiness

### 3.1 Rehearsal 1 results

Rehearsal 1 ran from 12 to 14 October 2026 on masked data. After cleansing, 5.8% of accounts were still duplicates or near-duplicates, against the agreed tolerance of 2%. Loading a 100,000-account sample took 7.5 hours, which extrapolates to about 31 hours for all 410,000 accounts. Reconciliation was not timed. Together with reconciliation this leaves a thin margin inside the 48-hour cutover window. The Data Migration Lead owns the cleansing plan and the cutover timings.

### 3.2 Test data masking

The masking script fails on 3 of the 41 tables, so those tables were loaded with synthetic placeholders and not with realistic data. The Data Migration Lead plans a fix by 28 October 2026, before SIT test data is cut.

## 4 Supplier commitments

### 4.1 BillCore vendor

The vendor's account manager confirmed verbally that release 4.2 is on track for 20 November 2026. The contract date is unchanged but no written confirmation has been received.

### 4.2 Payments gateway provider

Production credentials will be issued on request after the freeze. The Integration Lead has asked for them by 29 January 2027.

### 4.3 Hosted identity provider

The provider has booked the customer tenant configuration for 6 November 2026. They need our design questionnaire by 30 October 2026 to hold the slot.

### 4.4 Internal teams

The Network team has raised the firewall change request between the portal and BillCore. The change advisory board meets on 28 October 2026 and the rules are needed by 30 October 2026. The CRM team has not confirmed capacity for the customer-lookup service before December.

## 5 Next two weeks

- Escalate the sandbox patch with the BillCore vendor and track availability daily.
- Fix the masking script and re-cut the SIT data set.
- Decide whether to fund the 50% performance environment.
- Agree with the business how to treat the duplicate rate at Rehearsal 2.
- Send the identity provider the design questionnaire.
