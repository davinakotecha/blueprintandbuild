# Project Kestrel: High-Level Design

Customer self-service portal for Alderbrook Water (a fictional utility).
Version 1.2, 14 September 2026. Design baseline approved by the Design Authority on 29 May 2026.

> Synthetic example. Alderbrook Water, Project Kestrel and every number below are made up for the Blueprint & Build RAID log dashboard demo.

## 1 Purpose and objectives

### 1.1 Purpose

Project Kestrel gives Alderbrook's 410,000 household customers one place to view and pay bills, submit meter readings, report supply problems and manage contact preferences. Today every one of these tasks is a phone call or a paper form.

### 1.2 Success measures

- 30% of contact centre volume moves to self-service within 12 months of go-live.
- 40% of active accounts are registered on the portal within 6 months of go-live.
- Portal availability of 99.5% measured monthly.

## 2 Scope

### 2.1 In scope

- Responsive web portal for household customers.
- Customer registration and login through a hosted identity provider.
- Bill view and card payment through the payments gateway's hosted card page.
- Meter reading submission, validated by the legacy billing system ("BillCore").
- Notification service (email and SMS) for bills, readings and supply problems.
- Migration of household customer accounts from BillCore to the portal's account store.

### 2.2 Out of scope

- Native mobile apps.
- Business (non-household) customers.
- Replacing BillCore itself.
- Redesign of the paper bill.

## 3 Solution overview

### 3.1 Architecture

The portal front end talks to an API gateway. Behind the gateway sit four services: account, billing integration, payments and notifications. The hosted identity provider handles registration and login. All access to BillCore goes through the billing integration service, so the legacy system is never exposed to the internet.

### 3.2 Integrations

| System | Interface | Notes |
| --- | --- | --- |
| BillCore | REST API | Vendor limit of 50 calls per second per tenant. Expected peak is 80 calls per second in the two days after bills are issued, when customers submit readings. Peak load testing will confirm the figure. |
| BillCore | Batch meter-read endpoint | Planned in vendor release 4.2, due 20 November 2026. It would cut call volume sharply. |
| CRM | Customer-lookup service (read-only) | To be provided by the CRM team by 27 November 2026. The owner on the CRM side is still to be confirmed. |
| Payments gateway | Hosted card page | Keeps the portal out of most card-data (PCI) scope. |
| SMS gateway | REST API | Existing contract, shared with the contact centre. |

The Integration Lead owns the BillCore, payments gateway and SMS interfaces. The CRM interface belongs to the CRM team.

### 3.3 Non-functional requirements

- Page load under 3 seconds at the 95th percentile.
- 5,000 concurrent users.
- Availability of 99.5%, with a maximum planned outage of 4 hours a month.

## 4 Data migration

### 4.1 Approach

Extract from BillCore, cleanse, load into the portal account store, then reconcile record counts and balances. Three rehearsals are planned. Customers register for the portal using the email address held on their BillCore account. The Data Migration Lead owns the migration approach, the rehearsals and the cutover plan.

### 4.2 Data quality

Profiling in May 2026 estimated that 6% of the 410,000 accounts are duplicates or near-duplicates. The business agreed a maximum of 2% unresolved duplicates at cutover. Anything above that is merged by hand by Customer Operations.

### 4.3 Rehearsals

- Rehearsal 1: week of 12 October 2026, using masked data.
- Rehearsal 2: week of 23 November 2026, using unmasked production data.
- Rehearsal 3 (dress rehearsal): week of 25 January 2027.

### 4.4 Cutover

Cutover runs in a single weekend window from Saturday 13 February 2027 at 06:00 to Monday 15 February 2027 at 06:00 (48 hours). Billing is paused for the duration. The window is assumed to be long enough for the load and the reconciliation.

## 5 Security and compliance

### 5.1 Identity and access

Customers self-register and log in through a hosted identity provider. The provider's contract term ends on 31 December 2026. The portal's operations staff use single sign-on through the corporate directory.

### 5.2 Data protection

A Data Protection Impact Assessment (DPIA) must be approved before any rehearsal that uses unmasked production data, which means before Rehearsal 2 in the week of 23 November 2026. A date for the Data Protection Officer's review has not been agreed. The Security Lead owns the DPIA.

### 5.3 Security testing

An external penetration test of the portal is planned in the window 11 to 22 January 2027. Any high-rated finding must be fixed and retested before go-live. The Security Lead owns the penetration test.

### 5.4 Accessibility

The portal must meet WCAG 2.1 AA, which is a regulatory commitment. An independent accessibility audit is to be scheduled. No owner has been named for it.

## 6 Delivery plan

### 6.1 Milestones

| Milestone | Date |
| --- | --- |
| Design baseline approved | 29 May 2026 (done) |
| Build sprints 1 to 13 (two-week sprints, from 15 June) | ends 11 December 2026 |
| System integration test (SIT) | 9 November to 4 December 2026 |
| Performance test | 30 November to 11 December 2026 |
| User acceptance test (UAT) | 7 December 2026 to 15 January 2027 |
| Penetration test | 11 to 22 January 2027 |
| Go / no-go decision | 9 February 2027 |
| Go-live | 15 February 2027 |
| Hypercare ends | 31 March 2027 |

### 6.2 Testing and release

SIT runs against the BillCore sandbox and the payments gateway sandbox. The performance test needs a performance environment that the Infrastructure Lead will provide. UAT is run by ten business representatives who are expected to give eight hours a week each. The Test Manager owns the test plan and the test environments.

### 6.3 Training and change

About 240 contact centre agents need three hours of training each between 25 January and 12 February 2027. Training needs knowledge articles from Operations, which are not yet written. The launch announcement goes to registered customers by email. The Change Lead owns training and communications.

## 7 Assumptions

1. BillCore's API contract and behaviour do not change before go-live, apart from vendor release 4.2.
2. The hosted identity provider's current licence covers up to 410,000 registered customers without a change of pricing tier.
3. Ten business representatives give eight hours a week each to UAT.
4. The 48-hour cutover window is long enough for the load and the reconciliation.
5. The SMS gateway contract covers up to three times today's notification volume.
6. Go-live on 15 February 2027 falls outside the quarterly billing peak.

## 8 Dependencies

1. BillCore vendor delivers release 4.2 (batch meter-read endpoint) by 20 November 2026.
2. The hosted identity provider's customer tenant is configured by 6 November 2026. Owner: Security Lead.
3. The CRM team provides the customer-lookup service by 27 November 2026.
4. The Network team opens the firewall rules between the portal and BillCore by 30 October 2026. Owner: Infrastructure Lead.
5. The payments gateway provider issues production credentials by 29 January 2027. Owner: Integration Lead.

## 9 Constraints and open points

### 9.1 Constraints

- The go-live date of 15 February 2027 is fixed by commitments made to the regulator.
- The approved budget is £4.6 million, including 8% contingency (£368,000).

### 9.2 Open points

- Whether the portal must show priority-services (vulnerable customer) information. Not in the baseline scope.
- Whether a second phase (business customers) is funded. Decision expected from Finance.

## 10 Document history

### 10.1 Versions

| Version | Date | Change |
| --- | --- | --- |
| 1.0 | 29 May 2026 | Design baseline approved by the Design Authority |
| 1.1 | 3 August 2026 | Notification service added |
| 1.2 | 14 September 2026 | Data migration rehearsal plan added |

### 10.2 Items carried forward from earlier work

- The 48-hour cutover assumption dates from the feasibility study of 28 May 2026.
- The CRM customer-lookup dependency was first logged at the design workshop on 16 June 2026.
- The accessibility audit was flagged as having no owner when the baseline was approved on 29 May 2026.
