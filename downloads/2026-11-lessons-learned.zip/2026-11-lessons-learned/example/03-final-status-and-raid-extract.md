# Project Compass: final status report and RAID extract

Fenmoor Insurance (fictional). Made-up project, made-up report.

- Document: final status report with RAID extract
- Period: to 9 October 2026
- Author: Programme Manager

## 1 Overall status

- Overall: green for delivery, red for schedule, amber for cost.
- Delivery: all scope is live and the old wiki is switched off.
- Schedule: go-live was 6 July 2026, 20 working days after the 8 June 2026 plan.
- Cost: £688,000 against £640,000 approved (+7.5%).

## 2 Status by area

### 2.1 Content

- 2,820 articles are live. The last 410 were moved on 7 August 2026.
- 212 articles had to be migrated twice because they were edited in the old wiki after being moved.
- All 19 content areas now have a named owner and a monthly review date.

### 2.2 Platform and integration

- Search, editorial workflow and the CRM connector are live.
- First-page search success is 78%, against a target of 80%.
- Single sign-on and search capacity problems from the first week are closed.

### 2.3 People and support

- 340 of 340 agents trained. Weekly active use is 94%.
- Handover to the IT service desk is complete.

## 3 Open items at close

- Search relevance: 78% against the 80% target. The Service Owner will continue tuning.
- Handling-time benefit: the estimate is 7% against 10%. A measured figure is due after three more months of data.
- Documentation for the migration scripts is written, and the second person has run them once.

## 4 RAID extract

### 4.1 Risks

- R-07 (closed in week 3): the CRM connector might not be available in time. Rated amber. Owner: Integration Lead. Closed because the vendor's quote was believed to cover it.
- R-12 (materialised): content quality may be worse than expected. Rated amber. Owner: Content Lead. Opened in week 9 after the audit began.
- R-15 (materialised): only one person knows the migration scripts. Rated amber, no mitigation recorded. Owner: Content Lead.
- R-19 (open at go-live): search may be slow at peak load. Rated green. Owner: Test Lead. Raised in the week before go-live with no test planned.

### 4.2 Assumptions

- A-02 (invalid): the legacy articles are clean enough to migrate as they are. Owner: Content Lead. Never checked before the plan was baselined.
- A-04 (invalid): the vendor quote includes all the integrations we need. Owner: Integration Lead. Not checked with the vendor until week 15.
- A-06 (invalid): agents can be released for acceptance testing. Owner: Test Lead. Found false in June.

### 4.3 Issues

- I-03 (closed): 11 content areas had no named owner. Owner: Programme Manager. Closed in week 12 after escalation.
- I-09 (closed): search took 6.2 seconds at the 9am peak on the first morning live. Owner: Test Lead. Closed on day 5 after extra search capacity was added.
- I-11 (closed): single sign-on sessions expired every 30 minutes in the first week live, logging agents out mid-call. Owner: Integration Lead. Fixed on day 4 by changing a timeout setting.
- I-14 (closed): 22% of knowledge lookups still went to the old wiki in week 3. Owner: Service Owner. Closed when the wiki was switched off on 21 August 2026.
- I-16 (closed): 212 migrated articles were edited in the old wiki after the freeze notice. Owner: Content Lead. Closed when the articles were migrated again.

### 4.4 Dependencies

- D-02 (met late): the CRM connector module from the vendor. The vendor said two weeks and delivered after four, on 3 June 2026.
- D-05 (met late): compliance review of the design. Needed by 6 March 2026 and completed on 25 March 2026.
- D-07 (met): the telephony team's change window for cutover. Booked in week 10 and used on schedule.
