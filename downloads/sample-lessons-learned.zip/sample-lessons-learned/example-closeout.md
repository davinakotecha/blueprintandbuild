# Sample close-out notes (made up)

- We agreed the scope in week 1 but the data owner was not named until week 5, so the build waited.
- The test data was a copy of last year's file; two columns had changed, and nobody noticed until the demo.
- The handover call ran long because the documentation was in three places.
- Weekly status mails were short and everyone read them. Keep doing that.
