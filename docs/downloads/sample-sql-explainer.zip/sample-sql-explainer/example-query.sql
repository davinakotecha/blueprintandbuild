-- Sample input for the SQL explainer (made-up tables)
SELECT o.region,
       SUM(l.quantity * l.unit_price) AS revenue
FROM sample_orders AS o
JOIN sample_order_lines AS l ON l.order_id = o.order_id
WHERE o.order_date >= '2026-01-01'
GROUP BY o.region
ORDER BY revenue DESC;
