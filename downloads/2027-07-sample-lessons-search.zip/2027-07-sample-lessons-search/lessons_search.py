"""Sample script for the 'Lessons-learned search' MVP: finds a word in a folder of text notes.

Usage: python lessons_search.py <folder> <word>
Prints "file:line: text" for each matching line. It reads local files only and makes no network calls.
"""
import sys
from pathlib import Path


def search(folder, word):
    word = word.lower()
    for path in sorted(Path(folder).rglob("*")):
        if path.suffix.lower() not in (".md", ".txt") or not path.is_file():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for number, line in enumerate(text.splitlines(), start=1):
            if word in line.lower():
                yield f"{path.name}:{number}: {line.strip()}"


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("Usage: python lessons_search.py <folder> <word>")
    for hit in search(sys.argv[1], sys.argv[2]):
        print(hit)
