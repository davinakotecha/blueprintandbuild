# RAID log dashboard

> SAMPLE. This folder shows what a platform-hosted MVP looks like: just the card and this README. It is not a real MVP.

## Problem

Risks, assumptions, issues and dependencies are noted in many places. Project leads spend time collecting them, and overdue items slip through.

## Who it's for

Project leads and delivery managers who run a RAID log.

## Use it in 5 minutes

1. Open the dashboard from the Open button on its catalog card.
2. Pick a project from the list.
3. Read the four panels (Risks, Assumptions, Issues, Dependencies). Overdue items are marked.

## Limitations

- It shows made-up sample projects only; no client data.
- It reads a shared sheet, so changes show up after the next refresh.
- Shipped as is, with no support commitment.

## Owners

Sample data: Builder one and Builder two.

## Feedback

Post in #blueprint-and-build on Slack.
