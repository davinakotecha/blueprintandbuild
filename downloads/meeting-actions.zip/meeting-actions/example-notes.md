# Project Kestrel: weekly check-in (made-up notes)

Attendees: Priya (PM), Tom (data), Aisha (design), Marcus (dev lead)

- Dashboard layout agreed. Aisha will send the final mock-up by Friday.
- Test data is not ready. Tom is waiting on the supplier extract and says it could slip the demo. He will chase it tomorrow.
- Marcus thinks the reporting tool might not cope with the full data volume. Nobody has tested it. We are assuming the demo will use synthetic data only.
- Priya to book the room for the playback. Date to be agreed, probably the week after next.
- Security review has not started and the team needs it signed off before the playback. Marcus to ask who owns it.
- It would be good to have a style guide at some point.
