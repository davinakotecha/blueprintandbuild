# What a good answer looks like (for example-query.sql)

**What it returns:** one row per region, with the number of orders and the revenue for the first quarter of 2026, biggest revenue first. (SQL dialect assumed: any standard SQL.)

## How it runs

1. **`FROM customers` joined to `orders`.** Each customer is matched to their orders, so there is now one row per order, with the customer's region alongside.
2. **Joined again to `order_lines`.** Each order is matched to its lines. An order with three lines now appears three times. This is the step to watch.
3. **`WHERE` keeps orders dated 1 January to 31 March 2026.** It filters rows before they are grouped.
4. **`GROUP BY c.region`** collapses the rows into one per region.
5. **`SELECT`** counts rows and adds up `total_amount` within each region.
6. **`ORDER BY revenue DESC`** puts the biggest region first.

## What looks wrong

1. **The totals are too big (lines 5 and 6).** Joining to `order_lines` repeats each order once per line, but `COUNT(*)` and `SUM(o.total_amount)` count the order every time. An order worth 100 with three lines contributes 300. Fix: remove the `order_lines` join (nothing selected needs it), or sum at line level instead (`SUM(l.quantity * l.unit_price)`).
2. **The date range may miss the last day (line 9).** `o.order_date <= '2026-03-31'` is fine for a date column, but if `order_date` has a time part, orders after midnight on 31 March are lost. Safer: `o.order_date < '2026-04-01'`.
3. **Customers with no orders disappear.** An inner join drops them. That is fine for revenue, but not if you wanted a count of all customers per region.

## Try it
Run `SELECT COUNT(*) FROM orders WHERE order_date >= '2026-01-01' AND order_date < '2026-04-01'` and compare it with the sum of `orders` in your result. If your result is bigger, point 1 is the cause.
