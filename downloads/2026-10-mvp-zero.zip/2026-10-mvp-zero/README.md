# MVP #0: idea to one-page brief

> SAMPLE. This folder shows what an MVP looks like. It is not a real MVP; replace it with yours.

## Problem

A good idea often stalls because nobody has time to write it up properly. Without a brief, the builders cannot tell whether it fits in about six person-days or can be shown in five minutes.

## Who it's for

Anyone in the practice with an idea for the next Blueprint & Build cycle.

## Use it in 5 minutes

1. Unzip this folder.
2. Copy the `idea-to-brief` folder into `~/.claude/skills/` (all projects) or `.claude/skills/` inside one repo.
3. Ask Claude: "Turn this idea into a one-page MVP brief: a tool that checks slide decks for missing alt text."
4. Read the brief it returns, and edit it. Paste the result into the idea form.

`brief-template.md` shows the shape of the brief on its own.

## Limitations

- It writes a draft, not a decision. The builders still triage every idea.
- It only knows what you tell it. Do not paste client names or client data.
- Shipped as is, with no support commitment.

## Owners

Sample data: Builder one and Builder two.

## Feedback

Post in #blueprint-and-build on Slack.
