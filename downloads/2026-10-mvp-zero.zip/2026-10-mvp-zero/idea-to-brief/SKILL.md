---
name: idea-to-brief
description: Turns a rough idea into a one-page MVP brief with the problem, the audience, a five-minute demo and what is out of scope. Use when someone describes an idea for a small tool and wants it written up.
---

# Idea to one-page brief

Sample skill that ships inside the sample MVP #0.

When the user describes an idea:

1. Ask at most two questions if the problem or the audience is unclear. Otherwise do not ask.
2. Write a brief of one page or less, with these headings: Idea in one line, Problem and who has it, What the MVP does (three bullets at most), Five-minute demo, Data, Out of scope, Rough effort.
3. Keep to the ground rules: buildable in about six person-days, demoable in five minutes, no client data, approved tools only.
4. If the idea is bigger than that, say so and suggest the smallest slice that still demos well.
