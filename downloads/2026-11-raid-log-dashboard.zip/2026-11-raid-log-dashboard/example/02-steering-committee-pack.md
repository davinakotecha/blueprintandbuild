# Project Kestrel: Steering Committee Pack

Meeting of 16 October 2026. Prepared by the Programme Manager.

> Synthetic example. Alderbrook Water and Project Kestrel are fictional.

## 1 Attendance and purpose

Present: Programme Sponsor (chair), Programme Manager, Solution Architect, Integration Lead, Security Lead, Change Lead, Finance Lead, Product Owner, Procurement (observer). The purpose is to review progress, agree decisions and clear blockers before the SIT phase starts on 9 November 2026.

## 2 Overall status

Overall status: Amber. Build is on plan for the milestone of 11 December 2026, but delivery risk has risen because of the environment problems in section 5 and the funding decisions waiting in section 4.

## 3 Delivery progress

### 3.1 Milestones

- Sprints 1 to 8 are complete. Sprint 9 ran from 5 to 16 October 2026.
- SIT remains planned for 9 November to 4 December 2026.
- The Design Authority review of the notification service design was due on 16 October 2026 and did not take place. No new date has been set.

### 3.2 Sprint velocity

Sprint 9 delivered 30% fewer story points than planned. The causes were a bug backlog carried over from sprint 8 and unplanned leave. The Product Owner expects to recover over sprints 10 and 11. No action is needed from the committee this month.

## 4 Finance

### 4.1 Budget and contingency

The approved budget is £4.6 million with 8% contingency (£368,000). By the end of September, 70% of the contingency (£258,000) had been used. The Finance Lead owns the forecast and reports it monthly. The forecast is a further £140,000 of overspend if SIT runs longer than four weeks.

### 4.2 Funding decisions

- Phase 2 (business customers) needs a funding decision from Finance by 11 December 2026 so that the team can be retained after go-live.
- A training budget of £38,000 for contact centre training was requested on 14 September 2026. It was due for approval by 9 October 2026 and is still not approved.
- Finance confirmed on 9 October 2026 that go-live on 15 February 2027 avoids the quarterly billing peak. Assumption closed.

## 5 Risks and issues discussed

### 5.1 Risks

- Single point of knowledge. Only one person, the Billing Systems Specialist, knows BillCore's meter-read validation rules. They reduce to three days a week from 1 December 2026. The Programme Manager owns the mitigation: record the rules and pair a second engineer with them.
- The regulator has asked that the portal show priority-services (vulnerable customer) flags. This is not in the baseline. The Product Owner estimates 45 days of effort. The committee will decide at its next meeting on 30 October 2026. Without a decision the team cannot plan sprints 12 and 13.
- Procurement raised that the hosted identity provider's contract ends on 31 December 2026 and that nobody has started the renewal. No owner was assigned at the meeting.
- The Security Lead warned that the penetration test supplier has not yet been booked and the January slot could be lost.

### 5.2 Issues

- The BillCore sandbox has been unavailable for large parts of the last fortnight (detail in the readiness note). The Integration Lead owns the escalation to the vendor.
- The penetration test supplier has not been booked. The Security Lead needed to confirm the January slot by 9 October 2026 and did not. It was escalated.
- Contact centre training is not funded (see 4.2). The Change Lead cannot book trainers or rooms.

## 6 Decisions

1. Approved: keep the go-live date of 15 February 2027.
2. Approved: move the Design Authority notification review to the first available date; the Solution Architect to propose one.
3. Deferred to 30 October 2026: whether to add priority-services flags to scope.
4. Deferred: training budget, pending a revised business case from the Change Lead.

## 7 Actions

| Ref | Action | Owner | Due |
| --- | --- | --- | --- |
| A1 | Book the penetration test supplier and confirm the January 2027 slot | Security Lead | 23 October 2026 |
| A2 | Report BillCore sandbox availability to the committee every week | Integration Lead | 30 October 2026 |
| A3 | Propose a date for the notification service Design Authority review | Solution Architect | 23 October 2026 |
| A4 | Document BillCore meter-read validation rules and pair a second engineer | Programme Manager | 27 November 2026 |
| A5 | Revised training business case | Change Lead | 6 November 2026 |
| A6 | Bring the priority-services estimate and options to the next committee | Product Owner | 30 October 2026 |
