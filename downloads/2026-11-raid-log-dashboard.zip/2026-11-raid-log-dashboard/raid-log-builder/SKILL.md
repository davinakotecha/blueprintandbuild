---
name: raid-log-builder
description: Reads a high-level design plus any other project documents (steering committee packs, status reports, meeting notes, plans) and writes a strict raid.json, a RAID log of risks, assumptions, issues and dependencies. Every item cites the document and section it came from, carries a word-for-word source quote, and is marked "stated" or "inferred" so people can see what the documents say and what Claude worked out. Never invents owners or dates. Use when someone wants a RAID log built from project documents, or wants a file the RAID dashboard viewer can open.
metadata:
  examplePrompt: "Here are our high-level design and the latest steering committee pack. Use the raid-log-builder skill to write raid.json, then tell me the five items I should look at first."
  version: "1.0.0"
  builtBy: Blueprint & Build
---

# RAID log builder

Turn a high-level design and other project documents into a `raid.json` file: one list of **R**isks, **A**ssumptions, **I**ssues and **D**ependencies. The file opens in `raid-dashboard.html`, an offline viewer with a heat map, filters, owner workload, overdue flags and a source for every item.

The point of this skill is **traceability**. Anyone reading the log must be able to see which document and section each item came from, and which parts Claude made up. Stated facts and inferences look different on purpose.

## What you need

- A **high-level design** (or any document that describes scope, approach, milestones and constraints). Pasted text is fine.
- Optional but useful: steering committee packs, status reports, meeting notes, test or readiness notes, plans, an earlier RAID log.
- Ask for the **report date** if no document makes it obvious. Otherwise use today's date.

Ask at most **two** questions, and only if you cannot go on without the answer (for example "which date should the log be as of?"). Otherwise start work.

## Rules

1. **Cite the source for every item.** Each item has `source.document` (the file name or title) and `source.section` (the heading the text sits under, as written, for example `3.2 Integrations`). If the document has no headings, use the nearest label you can see, such as `Page 4` or `Paragraph 2`.
2. **Quote the source.** Put the exact words that support the item in `source.quote`, copied word for word, up to 300 characters. Do not tidy it, join two sentences or fix spelling inside it. If you cannot find words that support the item, either drop the item or set `basis` to `"inferred"` and quote the nearest passage.
3. **Mark inference clearly.** `basis` is `"stated"` when a document names the risk, assumption, issue or dependency in its own words. It is `"inferred"` when you spotted it by reading between the lines (for example a date that clashes with another date, or a missing owner). Never present an inference as stated.
4. **List your own judgement in `inferredFields`.** Probability and impact scores are almost never written in the documents, so they are always your judgement unless a document gives its own scores. Put every field you filled in yourself (`probability`, `impact`, `mitigation`, `rating`, `owner`) into `inferredFields`. The viewer shows these as "Claude's judgement".
5. **Never invent owners or dates.** Use `owner: null` unless a document names a person or a role as owner. Use `dueDate: null` and `raisedDate: null` unless a document gives the date. Do not guess a date from context. Missing owners and dates are findings, so list them under `gaps`.
6. **Do not guess a mitigation.** If a document gives a mitigation or next step, use it (and quote it if you can). If it does not, you may suggest one, but then add `"mitigation"` to `inferredFields`. If you have nothing sensible, use `null`.
7. **No client names and no personal names.** Use "the client" or the role (Programme Manager, Integration Lead). If the documents contain personal names, leave them out of every field, quotes included. If a name cannot be avoided in a quote, replace only the name with the role in square brackets, for example `[Test Lead]`.
8. **Numbers only if the source has them.** Do not make up costs, days or percentages.
9. **One thing per item.** If a sentence holds two separate risks, write two items and link them with `related`. If two documents describe the same item, write one item and cite the clearer document (mention the other in `description`).
10. **Keep closed things.** If a document says something was resolved, include it with `status: "closed"`. A log that only shows live items hides what was learned.
11. **Use the allowed values exactly.** The viewer ignores anything else.
12. Aim for 20 to 50 items. Fewer, sharper items beat a long list of vague ones.

## Steps

1. Read every document. Note each one's type, date (if shown) and headings.
2. Pull out candidate items. Look for: things that might go wrong (risks), things the plan takes for granted (assumptions), things that have already gone wrong (issues), and things that need someone else to deliver something (dependencies).
3. For each candidate, find the exact words that support it. Copy them into `source.quote`.
4. Fill in the fields. Set probability, impact and rating using the scales below, and record what you judged in `inferredFields`.
5. Link related items by id in `related`.
6. Number the items by type: `R-01`, `R-02`, `A-01`, `I-01`, `D-01`. Within each type, put the highest rating first.
7. Write `gaps`: things the documents leave unclear (no owner, no date, no mitigation, conflicting dates) and anything you chose not to include.
8. Run the self-check at the end of this file.
9. Save the result as `raid.json` if you can write files. If you cannot, print it as one JSON code block and ask the user to save it as `raid.json`.
10. Print the short summary described in "Finish".

## Output: raid.json

One JSON object. Plain JSON: no comments, no trailing commas, dates as `YYYY-MM-DD`, `null` for unknown.

### Top level

| Field | Type | Rule |
|---|---|---|
| `schemaVersion` | text | Always `"1.0"`. |
| `reportDate` | date | The date the log is "as of". The viewer measures overdue and ageing from this date. |
| `project` | object | See below. |
| `sources` | list | One entry for each document you read. |
| `gaps` | list of text | Open questions and things the documents left out. Can be empty. |
| `items` | list | The RAID items. |

### `project`

| Field | Type | Rule |
|---|---|---|
| `name` | text | Project name, with no client name. |
| `code` | text or `null` | Short project code if the documents give one. |
| `summary` | text or `null` | One or two sentences on what the project is and its fixed dates. |

### `sources[]`

| Field | Type | Rule |
|---|---|---|
| `document` | text | The file name or title, written exactly as you cite it in `items[].source.document`. |
| `type` | text | One of `"design"`, `"status report"`, `"RAID log"`, `"plan"`, `"meeting notes"`, `"other"`. |
| `title` | text or `null` | The document's own title. |
| `date` | date or `null` | The document's date. `null` if it is not shown. Do not guess. |

### `items[]`

| Field | Type | Rule |
|---|---|---|
| `id` | text | `R-01`, `A-01`, `I-01`, `D-01` and so on: the type letter, a hyphen and two digits. Unique. |
| `type` | text | `"R"` risk, `"A"` assumption, `"I"` issue, `"D"` dependency. |
| `title` | text | Up to 90 characters. A plain sentence that names the item. |
| `description` | text | One to three sentences: what it is and why it matters. Only what the documents say, plus clearly obvious consequences. |
| `owner` | text or `null` | A role or a person named as owner in a document. `null` if none is named. Never guess. |
| `workstream` | text | A short label for the part of the programme affected (for example `Integration`). Use the same spelling every time. |
| `probability` | 1 to 5 or `null` | See the scales. Use `null` for issues, because an issue has already happened. |
| `impact` | 1 to 5 | See the scales. |
| `rating` | text | `"low"`, `"medium"`, `"high"` or `"critical"`, worked out as shown below. |
| `status` | text | `"open"`, `"in-progress"`, `"monitoring"` or `"closed"`. |
| `raisedDate` | date or `null` | When the item arose, if a document says so. If it does not, you may use the date of the earliest document that mentions it, and then add a line to `gaps`. Otherwise `null`. |
| `dueDate` | date or `null` | The date a mitigation, decision or delivery is due. `null` if no document gives one. |
| `mitigation` | text or `null` | What is being done or planned. `null` if nothing is. |
| `source` | object | `document`, `section` and `quote`, see below. |
| `basis` | text | `"stated"` or `"inferred"`, see rule 3. |
| `inferredFields` | list of text | Fields that are your judgement, from `probability`, `impact`, `rating`, `mitigation`, `owner`. Can be empty. |
| `related` | list of text | Ids of linked items. Can be empty. |

### `source`

| Field | Type | Rule |
|---|---|---|
| `document` | text | Must match a `document` in `sources`. |
| `section` | text | The heading the quote sits under, as written. |
| `quote` | text | Word for word from the document, up to 300 characters. |

### Scales

**Probability** (the chance the risk happens, the assumption proves wrong, or the dependency is late):

| Score | Meaning |
|---|---|
| 1 | Rare: under 10% |
| 2 | Unlikely: 10 to 30% |
| 3 | Possible: 30 to 50% |
| 4 | Likely: 50 to 80% |
| 5 | Almost certain: over 80% |

**Impact** (what happens if it goes wrong, or what it is already costing):

| Score | Meaning |
|---|---|
| 1 | Negligible: absorbed by the team |
| 2 | Minor: a few days of slip or small rework |
| 3 | Moderate: a milestone slips by up to two weeks, or a deliverable is reduced |
| 4 | Major: a major milestone is missed, a large cost is added, or a regulatory commitment is at risk |
| 5 | Severe: the go-live date is lost, or the programme outcome fails |

If a document gives its own scales, use those and say so in `gaps`.

**Rating**:

- For risks, assumptions and dependencies, work out `score = probability x impact`. Then: `critical` for 15 to 25, `high` for 10 to 14, `medium` for 5 to 9, `low` for 1 to 4.
- For issues, `probability` is `null`, so rate on impact alone: `critical` for 5, `high` for 4, `medium` for 3, `low` for 1 or 2.

## Example

A trimmed risk (the full worked set is in the `example` folder of the MVP):

```json
{
  "id": "R-01",
  "type": "R",
  "title": "Meter-read peak exceeds the BillCore API limit",
  "description": "BillCore allows 50 calls per second per tenant. The expected peak is 80 calls per second in the two days after bills are issued, so the portal could be throttled just when customers submit readings.",
  "owner": "Integration Lead",
  "workstream": "Integration",
  "probability": 4,
  "impact": 5,
  "rating": "critical",
  "status": "in-progress",
  "raisedDate": "2026-07-20",
  "dueDate": "2026-11-20",
  "mitigation": "Use the batch meter-read endpoint planned in vendor release 4.2 (due 20 November 2026). Peak load testing will confirm the figure.",
  "source": {
    "document": "01-high-level-design.md",
    "section": "3.2 Integrations",
    "quote": "Expected peak is 80 calls per second in the two days after bills are issued, when customers submit readings."
  },
  "basis": "stated",
  "inferredFields": ["probability", "impact"],
  "related": ["D-01"]
}
```

The risk is `stated` because the design names the limit and the peak. The scores are Claude's judgement, so they are listed in `inferredFields`.

## Self-check before you save

Go through this list. Fix anything that fails.

- [ ] The file is valid JSON and `schemaVersion` is `"1.0"`.
- [ ] Every item has a `source` with `document`, `section` and `quote`, and the document is in `sources`.
- [ ] Every quote appears word for word in its document, and is 300 characters or fewer. (Search for it.)
- [ ] Every `section` is a heading or label that really exists in that document.
- [ ] No owner or date appears that a document does not give. Unknown means `null`.
- [ ] Every item that rests on your reading, not the documents' words, has `basis: "inferred"`.
- [ ] Every score and every mitigation you wrote yourself is named in `inferredFields`.
- [ ] Issues have `probability: null`. Everything else has a probability from 1 to 5.
- [ ] Each `rating` matches the rule above.
- [ ] Ids are unique and every id in `related` exists.
- [ ] No client names, company names or personal names anywhere, quotes included.
- [ ] `gaps` lists every missing owner, missing date and conflicting date you noticed.

## Finish

After saving, print a short summary:

1. How many items by type, and how many are `inferred`.
2. The five items to look at first (highest rating, then nearest due date), one line each.
3. Items with no owner and items with no mitigation.
4. Anything in `gaps` that needs a human decision.

Then say: "Open `raid-dashboard.html` and drop `raid.json` onto it. The file stays on your computer."

Remind the user to read the items marked **Inferred**: that is where Claude may have got it wrong.
