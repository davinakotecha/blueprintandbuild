---
name: sample-sql-explainer
title: Sample SQL explainer
description: Explains a SQL query or DAX measure in plain English, step by step, for a junior consultant, and points out likely mistakes.
examplePrompt: "Explain this SQL query step by step for someone new to the team, and tell me if anything looks wrong."
version: "0.1.0"
builtBy: Sample data
---

# SQL and DAX explainer

This is a sample skill that shows the SKILL.md format. It is not a real practice skill.

When the user pastes a SQL query or a DAX measure:

1. Say in one sentence what it returns.
2. Walk through it in the order it runs, in plain English, one short paragraph per step.
3. List up to three likely mistakes, such as a join that multiplies rows or a filter that is applied too late.
4. Offer a simpler version only if it gives the same result.

Never ask for real data. If the user pastes rows of data, tell them to use a few made-up rows instead.

See `example-query.sql` for a sample input.
