---
name: lessons-learned
description: Reads project documents such as close-out reports, retrospectives, status reports and RAID logs, and writes a strict lessons.json. Each lesson has a theme, what happened, a word-for-word evidence quote with its source, a root cause, the impact, a recommendation, the project phase it applies to and a confidence rating. Use when someone wants lessons learned from a finished or running project, or wants to turn notes into something the lessons-report viewer can open.
metadata:
  examplePrompt: "Here are the close-out report, the sprint retrospectives and the final status report from our last project. Use the lessons-learned skill to write lessons.json, then tell me the five lessons to carry forward."
  version: "1.0.0"
  builtBy: Blueprint & Build
---

# Lessons learned

Turn project documents into a `lessons.json` file that records what the project learned, with proof. The file opens in `lessons-report.html`, an offline viewer that shows the top lessons, the themes and root causes, and the exact words each lesson came from.

The point of this skill is **traceability**. Every lesson must point at words that are really in the documents. A lesson without evidence is an opinion, and the viewer is built to show the difference.

## What you need

- One or more project documents: close-out report, retrospective notes, status reports, a RAID log, a design, or anything similar. Pasted text is fine.
- Nothing else. If the user also tells you the project name and close date, use them.

Ask at most **two** questions, and only if you cannot go on without the answer (for example, "which of these documents is the final one?"). Otherwise start work.

## Rules

1. **Never invent evidence.** Every quote must be copied word for word from a document the user gave you. Do not tidy, shorten in the middle, join two sentences, or fix spelling inside a quote. You may cut a quote at a full stop.
2. **Every lesson needs at least one quote**, with the document name and the section it sits in. Use the section heading as written (for example `4.2 Content ownership`). If a document has no headings, use the nearest label you can see, such as `Page 3` or `Paragraph 2`.
3. **If you cannot find a quote, drop the lesson**, or keep it at `low` confidence with the best quote you do have, and list it under "gaps" in your summary. Never make up a quote to keep a lesson.
4. **Separate what the documents say from what you think.** If the document gives the root cause, set `rootCauseBasis` to `"stated"`. If you worked it out, set it to `"inferred"` and explain in `confidenceReason`.
5. **No names.** Do not include client names or personal names. Use "the client" or the role (Programme Manager, Test Lead). If the documents contain names, leave them out of every field, quotes included. Choose a sentence that has no name in it, or cut the quote at a full stop before the name. If a name cannot be avoided, replace only the name with the role in square brackets, for example `[Test Lead]`. That is the one edit allowed inside a quote.
6. **Numbers only if the source has them.** Do not estimate costs, days or percentages. Write "not stated" in `impact` if the documents give no figure.
7. **Recommendations must follow from the evidence.** One concrete action for the next project, written as an instruction ("Audit a sample of the source content in the first two weeks"). Not "improve communication".
8. **Include what went well.** Use `kind: "sustain"` for practices worth repeating, with `rootCauseCategory: "Good practice"`. A report that only lists failures is hard to act on.
9. **Merge duplicates.** If two documents describe the same event, write one lesson with several evidence entries, one per document. Recurrence across documents is a reason for higher confidence.
10. **Use the allowed values exactly**, including capital letters and the `&`. The viewer ignores anything else.
11. Aim for 12 to 30 lessons. Fewer, better lessons beat a long list of vague ones.

## Steps

1. Read every document. Note its type, its date if shown, and its headings.
2. List candidate lessons: things that went badly or slowly, things that cost time or money, things that went well, and things people said they would do differently.
3. For each candidate, find the exact sentence or sentences that support it. Copy them. If a candidate has no supporting text, drop it or mark it `low`.
4. Merge candidates that describe the same event. Give each lesson one theme, one phase and one root-cause category from the lists below.
5. Write the root cause, the impact and the recommendation. Set `impactLevel` and `confidence` using the rubrics below.
6. Number the lessons `L-01`, `L-02` and so on. Order them with the most important first: high impact, then high confidence.
7. Run the self-check at the end of this file.
8. Save the result as `lessons.json` if you can write files. If you cannot, print it as one JSON code block and ask the user to save it as `lessons.json`.
9. Print the short summary described in "Finish" and tell the user to open `lessons-report.html` and drop `lessons.json` onto it.

## Output: lessons.json

One JSON object. Plain JSON, no comments, no trailing commas, dates as `YYYY-MM-DD`.

### Top level

| Field | Type | Rule |
|---|---|---|
| `schemaVersion` | text | Always `"1.0"`. |
| `reportDate` | date | The day you wrote the file. |
| `project` | object | See below. |
| `sources` | list | One entry for each document you read. |
| `lessons` | list | The lessons, most important first. |

### `project`

| Field | Type | Rule |
|---|---|---|
| `name` | text | Project name, with no client name. |
| `code` | text or `null` | Short project code if the documents give one. |
| `summary` | text or `null` | One or two sentences on what the project was and how it ended. |
| `closedDate` | date or `null` | When the project closed, if a document says so. |

### `sources[]`

| Field | Type | Rule |
|---|---|---|
| `document` | text | The file name or title, exactly as you will cite it in `evidence`. |
| `type` | text | One of `"close-out report"`, `"retrospective"`, `"status report"`, `"RAID log"`, `"design"`, `"other"`. |
| `date` | date or `null` | The document's date. `null` if it is not shown. Do not guess. |

### `lessons[]`

| Field | Type | Rule |
|---|---|---|
| `id` | text | `L-01`, `L-02` and so on (`L-` and two or three digits). Unique. |
| `kind` | text | `"improve"` (do differently) or `"sustain"` (went well, keep doing). |
| `title` | text | Up to 90 characters. A plain sentence that states the lesson. |
| `theme` | text | One of the themes below. |
| `appliesToPhase` | text | The phase where the next project should act on it: one of the phases below. |
| `whatHappened` | text | One to three factual sentences. Only what the documents say. |
| `evidence` | list | One to four entries, see below. |
| `rootCause` | text | One sentence on why it happened. |
| `rootCauseCategory` | text | One of the root-cause categories below. Use `"Good practice"` for `sustain` lessons and never for `improve` lessons. |
| `rootCauseBasis` | text | `"stated"` if the documents give the cause, `"inferred"` if you worked it out. |
| `impact` | text | One sentence on what it cost or gave. Figures only if the source has them. |
| `impactLevel` | text | `"high"`, `"medium"` or `"low"`, see the rubric. |
| `recommendation` | text | One concrete action for the next project, as an instruction. |
| `confidence` | text | `"high"`, `"medium"` or `"low"`, see the rubric. |
| `confidenceReason` | text | One sentence on why you chose that confidence. Required for every lesson. |

### `evidence[]`

| Field | Type | Rule |
|---|---|---|
| `quote` | text | Word for word from the document. Up to 400 characters. |
| `document` | text | Must match a `document` in `sources`. |
| `section` | text | The heading the quote sits under, as written. |

### Themes (use these exact words)

`Planning & estimation`, `Scope & requirements`, `Data`, `Technology & integration`, `Testing & quality`, `Governance & decisions`, `Stakeholders & communication`, `People & change`, `Suppliers & contracts`, `Delivery & release`

### Phases (use these exact words)

`Initiation`, `Planning`, `Design`, `Build`, `Test`, `Deployment`, `Operations`, `Close`, `All phases`

### Root-cause categories (use these exact words)

`Unclear ownership`, `Late decision`, `Optimistic estimate`, `Unvalidated assumption`, `Poor or missing input data`, `Dependency not tracked`, `Skills or capacity gap`, `Communication gap`, `Process absent or not followed`, `Uncontrolled scope change`, `Supplier delivery`, `Good practice`

### Impact rubric

- **high**: moved a milestone, added more than 5% to cost, or harmed users or compliance.
- **medium**: caused rework or delay inside a milestone.
- **low**: minor friction. Use it for `sustain` lessons that were nice rather than decisive.

### Confidence rubric

- **high**: the documents state both the event and the cause, ideally in two or more documents. If the root cause is `"inferred"`, the lesson cannot be high.
- **medium**: the event is clear but the cause or the impact is your reading.
- **low**: one weak mention, or a quote that only half supports the lesson.

## Example

A trimmed lesson (the full worked set is in the `example` folder of the MVP):

```json
{
  "id": "L-06",
  "kind": "improve",
  "title": "Confirm in writing what each vendor quote includes before baselining",
  "theme": "Suppliers & contracts",
  "appliesToPhase": "Planning",
  "whatHappened": "The CRM connector is a separately licensed module that the vendor quote did not include. The gap was found in week 15, when the integration build began.",
  "evidence": [
    {
      "quote": "The vendor's quote did not include it, and this was found in week 15 when the integration build began.",
      "document": "01-closeout-report.md",
      "section": "4.5 CRM connector licence"
    }
  ],
  "rootCause": "Everyone believed the vendor quote covered the connector, and no one checked it with the vendor until the build began.",
  "rootCauseCategory": "Unvalidated assumption",
  "rootCauseBasis": "stated",
  "impact": "The unplanned licence added £38,000 and the integration build finished in week 25 against week 17 planned.",
  "impactLevel": "high",
  "recommendation": "Ask the vendor to confirm in writing which modules, licences and integrations the quote covers before the plan and budget are baselined.",
  "confidence": "high",
  "confidenceReason": "The close-out report and the RAID extract both state the event and the unchecked assumption, and give the cost."
}
```

## Self-check before you save

Go through this list. Fix anything that fails.

- [ ] The file is valid JSON, and `schemaVersion` is `"1.0"`.
- [ ] Every lesson has between one and four evidence entries.
- [ ] Every quote appears word for word in its document, and is 400 characters or fewer. (Search for it.)
- [ ] Every `document` in `evidence` is also listed in `sources`.
- [ ] Every `section` is a heading or label that really exists in that document.
- [ ] Every theme, phase and root-cause category is spelled exactly as in the lists.
- [ ] `sustain` lessons use `"Good practice"`, and `improve` lessons never do.
- [ ] Every inferred root cause is marked `"inferred"` and explained in `confidenceReason`, and none is rated `high`.
- [ ] No client names, company names or personal names anywhere, quotes included.
- [ ] No figure appears that is not in the documents.
- [ ] Each recommendation is a concrete action, not a slogan.
- [ ] Ids run `L-01`, `L-02` and so on with no gaps or repeats.

## Finish

After saving, print a short summary:

1. How many lessons: improve and sustain.
2. The count by theme and by confidence.
3. Lessons you dropped or kept at `low` because the evidence was thin, and why.
4. Gaps: themes or phases the documents say nothing about, so the user knows what the report cannot tell them.
5. The five lessons to carry forward, one line each.

Then say: "Open `lessons-report.html` and drop `lessons.json` onto it. The file stays on your computer."

See `example-closeout.md` (and the `example/` folder in the MVP) for a worked input.
