# RAID log dashboard

A Claude skill that builds a RAID log from your project documents, and an offline dashboard that shows it. A RAID log is the list of a project's **R**isks, **A**ssumptions, **I**ssues and **D**ependencies.

## Problem

RAID items live in many places: the design, the steering pack, someone's notes. Project leads spend hours pulling them together, and when a log does exist nobody can tell which items come from the documents and which someone guessed. Overdue items and missing owners slip through.

## Who it's for

Project leads, delivery managers and architects who need a RAID log from a high-level design and a few other documents, in minutes rather than days.

## What's in this folder

| File | What it is |
|---|---|
| `raid-dashboard.html` | The dashboard. One file, no install, works offline. Open it by double-clicking. |
| `raid-log-builder/SKILL.md` | The Claude skill. It reads your documents and writes `raid.json`. |
| `example/` | A made-up project (Project Kestrel): three short documents and the `raid.json` the skill produces from them. |

## Use it in 3 steps

1. **Give Claude your documents and the skill.** Add the `raid-log-builder` folder to Claude as a skill (or paste `SKILL.md` into the chat). Then upload your high-level design and any other documents, such as steering packs or status reports, and ask: *"Use the raid-log-builder skill to write raid.json from these documents."*
2. **Save the file.** Claude writes `raid.json`. If it prints the JSON in the chat instead, save it as `raid.json`.
3. **Open the dashboard and drop the file on it.** Double-click `raid-dashboard.html`, then drag `raid.json` anywhere on the page. Nothing is uploaded.

## What you see

- **Four summary tiles**: open risks and issues, overdue, high or critical, and due this fortnight. Each is red, amber or green, shown with a word and a shape as well as a colour. Click a tile to filter the log.
- **A 5 by 5 heat map** of open risks by probability and impact. Click a cell to list only those risks. It works with the arrow keys too.
- **Tabs** for Risks, Assumptions, Issues and Dependencies, with search, sorting, and filters for owner, status, rating, workstream and source basis.
- **Owner workload**: who holds the most open items and how severe they are. Items with no named owner are grouped as "Unassigned", because that is a finding.
- **Ageing and overdue flags**, measured from an **as-of date** you can change. It starts at the report date in the file, so you can ask "what will be overdue on 1 December?" without editing anything.
- **A source for every item**: the document, the section, and the exact words. A badge says whether the item is **Stated** (the document says it) or **Inferred** (Claude worked it out). Scores Claude judged are labelled too.
- **Export** to CSV (everything, or just the current view) and a **print layout**: choose "Print or save as PDF" and use your browser's "Save as PDF".

## Ten-minute demo

1. **0:00 to 1:00. The problem.** "Our RAID logs are scattered and nobody can tell which items are facts." Show the three documents in `example/`: a design, a steering pack and a readiness note.
2. **1:00 to 2:30. Make the log.** In Claude, upload the three documents and the skill and run the prompt above. While it works, open `raid-dashboard.html` and click **Load the example project** (the made-up result you would get).
3. **2:30 to 4:00. The headline.** Read the four tiles. Point at the heat map: "Where are the dangerous risks?" Click the cell at probability 4, impact 4 and see which two risks sit there.
4. **4:00 to 5:30. Who is overloaded?** Click the top bar in **Owner workload**. Then click **Unassigned**: six open items have no owner. "The documents never said who owns them, and the skill did not make one up."
5. **5:30 to 7:00. Trust.** Open risk R-01 and read the quote and the section. Filter **Source basis** to **Inferred** and show the items Claude worked out. "This is what to check first."
6. **7:00 to 8:00. Time travel.** Change the **As of date** to 1 December 2026 and watch the overdue count climb. Click **Back to report date**.
7. **8:00 to 9:00. Share it.** Click **Export CSV** and open it in Excel. Then **Print or save as PDF** for the steering committee.
8. **9:00 to 10:00. Your turn.** Ask the room for a real (internal, public or synthetic) design and run the skill on it live, or agree who will try it this week.

## Data rules

- **Internal, public or synthetic data only.** Never put client data, client names or personal data into Claude or into this dashboard. The skill is told to leave names out, but check the result.
- The dashboard works offline and makes no network calls. A `raid.json` you open stays on your computer.
- The example project, **Project Kestrel** and **Alderbrook Water**, is made up.

## Limitations

- Claude can misread a document. Read every **Inferred** item, and treat probability and impact scores as a first draft: the documents rarely give them.
- The log is only as good as the documents. If a document is silent about an owner or a date, the log says so (it shows "No owner named" or "No date") and does not fill the gap.
- The dashboard shows one `raid.json` at a time and keeps nothing between visits. Save changes by editing the file or re-running the skill.
- Shipped as is, with no support commitment.

## Owners

Davina Kotecha and Owen Rogan, AI & Analytics practice (Blueprint & Build team).

## Feedback

Post in #blueprint-and-build on Slack.
