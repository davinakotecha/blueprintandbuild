-- Made-up tables, for trying the SQL explainer
SELECT c.region,
       COUNT(*)                     AS orders,
       SUM(o.total_amount)          AS revenue
FROM customers AS c
JOIN orders AS o       ON o.customer_id = c.customer_id
JOIN order_lines AS l  ON l.order_id = o.order_id
WHERE o.order_date >= '2026-01-01'
  AND o.order_date <= '2026-03-31'
GROUP BY c.region
ORDER BY revenue DESC;
