# Project Compass: sprint retrospectives

Fenmoor Insurance (fictional). Made-up project, made-up notes. Three of the fourteen sprint retrospectives are kept here.

## 1 Sprint 4 retrospective (27 February 2026)

Attended by the Programme Manager, Content Lead, Integration Lead, Test Lead and two agent champions.

### 1.1 Went well (Sprint 4)

- The first two show-and-tells found 12 usability issues before any sign-off meeting.
- The agent champions are in place and already testing the search screen.
- The decision log is being used. Nobody argues about what was agreed.

### 1.2 Went badly (Sprint 4)

- The article taxonomy decision is waiting for the March Steering Group on 12 March, so migration mapping cannot start.
- 11 of the 19 content areas still have no named owner, and nobody is chasing them.
- The content audit should have started in week 3. It has not started, and we do not know how clean the old articles are.

### 1.3 Actions (Sprint 4)

- Content Lead to start the audit on 2 March, beginning with the five largest content areas.
- Programme Manager to ask the Steering Group to name the 11 missing content owners.
- Programme Manager to ask for an extra Steering Group slot for the taxonomy decision.

## 2 Sprint 10 retrospective (22 May 2026)

Attended by the Programme Manager, Content Lead, Integration Lead, Test Lead, Service Desk Lead and three agent champions.

### 2.1 Went well (Sprint 10)

- Four article templates and the style guide are working. Reviewers now add very few comments.
- The champions tested the last three releases and found problems the project team had missed.
- Service Desk Lead has joined the sprint reviews, so support will not meet the platform for the first time at go-live.

### 2.2 Went badly (Sprint 10)

- The freeze notice for migrated articles went out on 16 March to team managers only. By 24 April, 212 migrated articles had been edited in the old wiki and each had to be migrated again.
- Migration stopped for two weeks in May because only the Content Lead knew how the migration scripts and the content mapping worked, and they were on leave.
- Three features were added in sprints 5 and 6 on a verbal yes. Nobody wrote a change request and the integration work slipped.
- We still cannot start relevance tuning because the content is not all loaded.

### 2.3 Actions (Sprint 10)

- Integration Lead to chase the vendor for the CRM connector module and report every Friday.
- Content Lead to write down the migration steps so a second person can run them.
- Programme Manager to reject any new request that is not on the change log.

## 3 Sprint 14 retrospective (17 July 2026)

The last retrospective, held two weeks after go-live. Attended by the whole team and the Service Desk Lead.

### 3.1 Went well (Sprint 14)

- The cutover rehearsals paid off. Go-live night was dull, which is what we wanted.
- Eight floor-walkers on the three sites meant agents had someone to ask. Service desk calls dropped quickly.
- The champions ran the floor briefings and did not need the project team to do it for them.

### 3.2 Went badly (Sprint 14)

- Single sign-on sessions expired every 30 minutes in the first week and agents were logged out in the middle of calls.
- Search was slow at the 9am peak on the first morning. The load test only used 80 simulated users.
- The vendor said the CRM connector would take two weeks to deliver and it took four. We did not check progress during the wait.
- Training was a single 60-minute session. Agents on the two smaller sites said it felt rushed.
- Nobody had decided when to switch off the old wiki, so agents kept using it.

### 3.3 Actions (Sprint 14)

- Service Owner to set the switch-off date for the old wiki and tell every team manager.
- Test Lead to add a full-load search test to the release checklist.
- Programme Manager to put the lessons into the close-out report.
