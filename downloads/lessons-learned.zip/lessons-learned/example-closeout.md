# Project Compass: close-out report

Fenmoor Insurance (fictional). This is a made-up project used to demonstrate the Blueprint & Build lessons-learned tool. Nothing in it is real.

- Document: close-out report, version 1.0
- Date: 16 October 2026
- Author: Programme Manager
- Approved by: Steering Group

## 1 Summary

Project Compass replaced the contact-centre knowledge base (an intranet wiki of about 4,200 articles) with a new knowledge platform that has search, article templates and an editorial workflow. It serves 340 agents on three sites.

The project started on 5 January 2026. Go-live was planned for 8 June 2026 and happened on 6 July 2026, 20 working days late. The approved budget was £640,000 and the final cost was £688,000, which is £48,000 (7.5%) over.

The platform is now the only knowledge source for agents. The old wiki was switched off on 21 August 2026.

## 2 Outcomes against plan

### 2.1 Delivery measures

- Go-live: planned 8 June 2026, actual 6 July 2026.
- Agents trained: 340 of 340 by 3 July 2026.
- Articles: 2,410 live at go-live. The other 410 of the 2,820 target were moved by 7 August 2026.
- Weekly active agents reached 94% by week 6 after go-live.

### 2.2 Business measures

- Handling time on knowledge-lookup calls: the target was a 10% reduction, and the estimated reduction by week 8 after go-live was 7%.
- The handling-time baseline was only taken in week 24, so the 7% is an estimate and not a measured result.
- First-page search success: the target was 80%. It was 62% at go-live and 78% in week 8 after go-live.

## 3 What went well

### 3.1 Weekly show-and-tell

From week 3 the team ran a 30-minute show-and-tell every Thursday. An average of 18 people attended, and 31 usability issues were raised and fixed before the build was complete. Several stakeholders said it was the first time they had seen a project's work before a sign-off meeting.

### 3.2 Agent champions

Twelve agent champions from the three sites were recruited in week 4, before the first build was ready. They tested every release and ran the floor briefings. Their feedback changed the article layout twice.

### 3.3 Decision log

A decision log was kept from the first week. It recorded 57 decisions, each with an owner, a date and the reason. It settled three disputes about scope without escalation.

### 3.4 Article templates and style guide

Four article templates and a one-page style guide were agreed in sprint 2. Review comments per article fell from an average of 6.1 to 2.4 over the next four sprints.

### 3.5 Cutover rehearsals

Two full cutover rehearsals were run before go-live. The first took 7 hours 40 minutes and the second took 4 hours 5 minutes. The real cutover finished in 4 hours 20 minutes, well inside the 8-hour window.

### 3.6 Hypercare and service desk involvement

Eight floor-walkers were on site for the first two weeks after go-live. Service desk calls about the platform fell from 96 on day 1 to 11 on day 10.

The IT service desk joined the sprint reviews from sprint 6. Handover to support took 2 days against 10 planned.

## 4 What did not go well

### 4.1 Content migration

The plan assumed the legacy articles were clean and ready to move. The content audit, planned for weeks 3 to 5, did not start until week 9.

When it ran, the audit found that 1,380 of the 4,200 articles (33%) were duplicates or out of date. Migration of the 2,410 articles needed at go-live took 14 weeks against 6 planned. Six content contractors were added for 8 weeks to catch up, at a cost of £31,000.

### 4.2 Content ownership

At kick-off, 11 of the 19 product-line content areas had no named owner. Articles were reviewed by whoever was free, and content sign-off took an average of 9 working days against 3 planned. Owners were named by week 12, but only after the Programme Manager escalated to the Steering Group.

### 4.3 Sign-off and governance

The plan allowed 5 working days for design sign-off and did not include a compliance review. The Compliance Lead was not a member of the Steering Group and the review request reached them in week 7. Design sign-off was planned for 6 March and happened on 25 March, 19 calendar days late.

The Steering Group met monthly. Decisions that needed the group waited up to four weeks for the next meeting.

### 4.4 Search relevance tuning

Relevance tuning could not start until the migrated content was loaded, so it began in week 22, nine weeks later than planned. At the start of tuning only 41% of test searches returned the right article on the first page. The target was 80%.

### 4.5 CRM connector licence

The CRM connector (screen-pop and case linking) is a separately licensed module. The vendor's quote did not include it, and this was found in week 15 when the integration build began.

Procurement approval for the extra £38,000 took 17 working days. The vendor delivered the module on 3 June, four weeks after the order. The integration build finished in week 25 against week 17 planned.

### 4.6 Late scope additions

Three features were added in sprints 5 and 6 on verbal approval: article favourites, expiry reminders and a feedback button. They used 41 developer days and were not recorded as change requests. That time had been set aside for integration and tuning.

### 4.7 Testing

The user acceptance test cases were written by the project team, because agents could not be released from the floor during the June peak in call volumes. Two severity 1 defects were found in the first week live that agent-written cases would probably have caught.

The load test used 80 simulated users. The platform serves 340 agents, and on the first morning live a search took 6.2 seconds at the 9am peak against a target of 2 seconds.

### 4.8 Training and switching off the old wiki

Training was one 60-minute session per agent in the week before go-live. In the week 2 survey, 38% of agents said they did not feel ready.

The decision on when to switch off the old wiki was not taken until week 2 after go-live. In week 3, 22% of knowledge lookups still went to the old wiki. It was switched off on 21 August.

## 5 Budget and schedule

- Approved budget: £640,000. Final cost: £688,000. Variance: £48,000 (7.5%).
- The CRM connector licence added £38,000 and the content contractors added £31,000.
- An underspend of £21,000 on training and travel, because training was delivered online, offset part of this.
- Go-live was 20 working days late. The main causes were the late content audit, the connector licence and the late start of relevance tuning.

## 6 Recommendations

- Audit and name an owner for every content area in the first two weeks.
- Confirm in writing what each vendor quote includes before the plan is baselined.
- Put compliance and legal reviewers on the Steering Group, or book their review time in the plan.
- Capture benefit baselines before the build starts.
- Test with agent-written cases and at full load.
- Keep the show-and-tell, the champion network and the decision log on the next project.
