# One-page MVP brief (sample template)

**Idea in one line:**

**Problem and who has it:**

**What the MVP does (three bullets at most):**

-
-
-

**Five-minute demo:** what the audience sees, step by step.

**Data:** internal, public or synthetic only. No client data.

**Out of scope for now:**

**Rough effort:** can two people ship it in about six days? Why or why not?
