---
name: sample-lessons-learned
description: Reads pasted project close-out notes and groups the lessons by theme, such as planning, data and handover, with one suggested action for each.
examplePrompt: "Here are the close-out notes from our last project. Group the lessons by theme and suggest one action for each."
version: "0.1.0"
builtBy: Sample data
---

# Lessons learned

This is a sample skill that shows the SKILL.md format. It is not a real practice skill.

When the user pastes project close-out notes:

1. Pull out each lesson as one short sentence.
2. Group the lessons under themes such as Planning, Data, People and Handover. Leave a theme out if nothing fits it.
3. Under each theme, suggest one concrete action for the next project.
4. Finish with a three-line summary the user can paste into Slack.

Never include client names or client data in the output. If the notes contain them, replace them with "the client".

See `example-closeout.md` for a sample input.
