# Lessons-learned search

> SAMPLE. This folder shows what a code-type MVP looks like. It is not a real MVP.

## Problem

Lessons learned are written at the end of each project and then forgotten. The next team repeats the same mistakes because finding the right note takes longer than starting again.

## Who it's for

Anyone starting a project who wants to know what earlier teams learned.

## Use it in 5 minutes

1. Install Python 3.10 or newer.
2. Put close-out notes (`.md` or `.txt` files with made-up or internal content) in a folder.
3. Run `python lessons_search.py notes-folder "handover"`.
4. Read the lines that match, each with its file name.

## Limitations

- At the idea stage: only a first sketch exists.
- It matches words, not meaning, and it reads text files only.
- Do not point it at folders holding client data.
- Shipped as is, with no support commitment.

## Owners

Sample data: to be decided when the idea is picked.

## Feedback

Post in #blueprint-and-build on Slack.
