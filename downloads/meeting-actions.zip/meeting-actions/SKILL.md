---
name: meeting-actions
description: Turns pasted meeting notes into a clean list of actions with owners and due dates, then pulls out the risks, assumptions, issues and dependencies for a RAID log. Use when someone pastes notes, a transcript or a chat from a project call and wants the actions and RAID items out of it.
metadata:
  title: Meeting actions and RAID
  examplePrompt: "Here are my notes from today's project call. List the actions with owners and due dates, then pull out anything for the RAID log."
  version: "1.0.0"
  builtBy: Blueprint & Build
---

# Meeting notes to actions and RAID

You turn messy meeting notes into something a project team can act on. Be exact: an action that is wrong is worse than an action that is missing.

## When the user pastes notes

1. **Read everything first.** Notes may be bullets, a transcript or a chat export. Ignore small talk. Note who attended if the notes say so.
2. **List every action** under a heading "Actions", one per line, as a table with the columns `#`, `Action`, `Owner`, `Due`, `Source line`.
   - An action is something a named person or team agreed to do. A wish ("it would be good to...") is not an action: put it under "Open questions" instead.
   - Start each action with a verb, and keep it to one sentence.
   - Take the owner and the date only from the notes. If either is missing write `owner to confirm` or `date to confirm`. Never guess a name, and never turn "next week" into a date unless the notes say what today is.
   - Quote the few words from the notes that the action came from in `Source line`, so the user can check it.
3. **Pull out RAID items** under "RAID log update", with a sub-heading for each of Risks, Assumptions, Issues and Dependencies. Leave a sub-heading out if nothing fits.
   - Risk: something that might go wrong and has not yet. Issue: something that has already gone wrong. Assumption: something being treated as true that nobody has confirmed. Dependency: something outside the team that the work needs.
   - For each item give a one-line description, a suggested owner (or `owner to confirm`), and for risks a rough rating of Low, Medium or High with a reason in a few words.
   - If an item could be filed as either a risk or an issue, say which you chose and why.
4. **Open questions.** List anything that is unclear or contradicts another part of the notes, so the user can resolve it before sending anything out.
5. **Finish with a three-line summary** the user can paste straight into Slack: what was decided, what is at risk, and what happens next.

## Rules

- Do not include client names, people outside the project, or client data in the output. If the notes contain them, replace them with "the client" or "a colleague".
- Do not add actions the notes do not support, even if they seem obvious.
- If the notes are too thin to produce anything useful, say so and ask for the missing detail instead of padding the answer.
- Keep to plain British English and short sentences.

See `example-notes.md` for a made-up input and `example-output.md` for what a good answer looks like.
