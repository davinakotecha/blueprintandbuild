# Idea to one-page brief

An idea only becomes an MVP when somebody can see, on one page, what problem it solves, who has it, what the demo is and how big it is. This MVP does that two ways:

- **The brief builder on the Submit page** of the Blueprint & Build site. Fill in the fields, and it copies a neatly formatted brief for the Slack channel.
- **The `idea-to-brief` Claude skill** in this folder. Describe your idea in plain words and Claude writes the brief for you, asking at most two questions.

Both use the same format, so a brief from either one can be pasted straight into the channel.

## The format

| Section | What goes in it |
|---|---|
| Idea in one line | One sentence, up to 140 characters |
| Problem and who has it | Who has the problem, how often, and what changes if it is solved |
| What the MVP does | Three bullets at most |
| Ten-minute demo | What the audience sees, step by step |
| Data | Internal, public or synthetic only. **No client data.** |
| Out of scope for now | What you are deliberately leaving out |
| Rough effort | Can two people ship it in about six days? Why or why not? |

`brief-template.md` shows the shape on its own.

## Use the skill in 5 minutes

1. Unzip this folder.
2. Copy the `idea-to-brief` folder into `~/.claude/skills/` (all projects) or `.claude/skills/` inside one repo. In the Claude app, upload the folder as a zip under Customize > Skills.
3. Ask Claude: "Turn this idea into a one-page MVP brief: a tool that checks slide decks for missing alt text."
4. Read the brief it returns and edit it. Paste the result in the Slack channel, or use the Submit page.

## Ground rules it checks

- Buildable by two people in about six days.
- Demoable in ten minutes.
- No client data, and approved tools only.

If an idea is bigger than that, the skill says so and suggests the smallest slice that still demos well.

## Limitations

- It writes a draft, not a decision. The builders still triage every idea.
- It only knows what you tell it. Do not paste client names or client data.
- Shipped as is, with no support commitment.

## Owners

Davina Kotecha and Owen Rogan, the Blueprint & Build builders. Questions and feedback: post in the Slack channel.
