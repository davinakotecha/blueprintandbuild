# What a good answer looks like (for example-notes.md)

## Actions

| # | Action | Owner | Due | Source line |
|---|---|---|---|---|
| 1 | Send the final dashboard mock-up | Aisha | Friday | "Aisha will send the final mock-up by Friday" |
| 2 | Chase the supplier for the test data extract | Tom | Tomorrow (date to confirm) | "He will chase it tomorrow" |
| 3 | Book the room for the playback | Priya | date to confirm | "Priya to book the room" |
| 4 | Find out who owns the security review | Marcus | date to confirm | "Marcus to ask who owns it" |

## RAID log update

### Risks
- **Reporting tool may not cope with the full data volume.** Owner: Marcus (to confirm). Rating: Medium, because it is untested and the demo is close.

### Assumptions
- The demo will use synthetic data only. Owner: Priya (to confirm).

### Issues
- **Test data is not ready**, and could slip the demo. Owner: Tom. (Filed as an issue because the delay has already happened; it becomes a risk to the demo date if the extract arrives late.)

### Dependencies
- The supplier's data extract, needed before the demo.
- Security review sign-off, needed before the playback. It has not started and has no owner yet.

## Open questions
- What is the playback date? "Probably the week after next" is not fixed.
- Who owns the security review?

(The line about a style guide is a wish, not an action, so it is not listed above.)

## Slack summary
Decided: dashboard layout is agreed and the mock-up lands Friday.
At risk: test data is late, the reporting tool is untested at full volume, and the security review has no owner.
Next: Tom chases the extract, Marcus finds the review owner, Priya books the playback room.
