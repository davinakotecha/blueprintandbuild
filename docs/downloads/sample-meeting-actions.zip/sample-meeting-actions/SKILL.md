---
name: sample-meeting-actions
description: SAMPLE skill. Turns pasted meeting notes into a list of actions with owners and due dates, and flags risks, assumptions, issues and dependencies for a RAID log.
examplePrompt: "Here are my notes from today's project call. List the actions with owners and due dates, then pull out anything for the RAID log."
version: "0.1.0"
builtBy: Sample data
---

# Meeting notes to actions

This is a sample skill that shows the SKILL.md format. It is not a real practice skill.

When the user pastes meeting notes:

1. List every action as "Owner: action (due date)". If the owner or date is not in the notes, write "owner to confirm" or "date to confirm"; never guess.
2. Add a short RAID section: Risks, Assumptions, Issues, Dependencies. Leave a heading out if nothing fits it.
3. Finish with a three-line summary the user can paste into Slack.

Do not include client names or client data in the output. If the notes contain them, replace them with "the client".

See `example-notes.md` for a sample input.
