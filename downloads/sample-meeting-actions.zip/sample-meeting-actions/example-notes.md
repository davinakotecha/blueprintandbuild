# Sample meeting notes (made up)

Weekly check-in for a made-up internal project.

- Dashboard layout agreed. Builder one will send the mock-up on Friday.
- Test data is not ready yet. Waiting on the data owner; could slip the demo.
- Assumption: the demo uses synthetic data only.
- Someone needs to book the room for the playback.
